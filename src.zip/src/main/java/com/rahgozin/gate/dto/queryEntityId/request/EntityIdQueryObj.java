package com.rahgozin.gate.dto.queryEntityId.request;


public class EntityIdQueryObj {
    SubAccessCode subAccessCode;

    public SubAccessCode getSubAccessCode() {
        if (subAccessCode == null)
            subAccessCode = new SubAccessCode();
        return subAccessCode;
    }

    public void setSubAccessCode(SubAccessCode subAccessCode) {
        this.subAccessCode = subAccessCode;
    }
}
