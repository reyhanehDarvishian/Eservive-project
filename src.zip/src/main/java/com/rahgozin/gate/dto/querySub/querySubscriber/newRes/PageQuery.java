package com.rahgozin.gate.dto.querySub.querySubscriber.newRes;

import javax.xml.bind.annotation.XmlAttribute;


public class PageQuery {
    String pageSize;
    String startNum;
    String totalNum;

    public void setPageSize(String pageSize) {
        this.pageSize = pageSize;
    }

    @XmlAttribute(name = "pageSize")
    public String getPageSize() {
        return pageSize;
    }

    public void setStartNum(String startNum) {
        this.startNum = startNum;
    }

    @XmlAttribute(name = "startNum")
    public String getStartNum() {
        return startNum;
    }

    public void setTotalNum(String totalNum) {
        this.totalNum = totalNum;
    }

    @XmlAttribute(name = "totalNum")
    public String getTotalNum() {
        return totalNum;
    }

}