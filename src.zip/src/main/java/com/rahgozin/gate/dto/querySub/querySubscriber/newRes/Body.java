package com.rahgozin.gate.dto.querySub.querySubscriber.newRes;

import com.fasterxml.jackson.annotation.JsonProperty;

import javax.xml.bind.annotation.XmlElement;


public class Body {
    @JsonProperty("querySubscriberRspMsg")
    QuerySubscriberRspMsg querySubscriberRspMsg;

    @XmlElement(name = "querySubscriberRspMsg")
    public QuerySubscriberRspMsg getQuerySubscriberRspMsg() {
        if (querySubscriberRspMsg == null) querySubscriberRspMsg = new QuerySubscriberRspMsg();
        return querySubscriberRspMsg;
    }

    public void setQuerySubscriberRspMsg(QuerySubscriberRspMsg querySubscriberRspMsg) {
        this.querySubscriberRspMsg = querySubscriberRspMsg;
    }

}