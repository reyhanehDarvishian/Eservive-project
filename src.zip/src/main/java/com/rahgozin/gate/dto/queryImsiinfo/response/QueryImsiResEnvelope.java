package com.rahgozin.gate.dto.queryImsiinfo.response;

import com.fasterxml.jackson.annotation.JsonProperty;

import javax.xml.bind.annotation.XmlElement;


public class QueryImsiResEnvelope {

    @JsonProperty("Body")
    BodyBean bodyBean;

    @XmlElement(name = "Body")
    public BodyBean getBodyBean() {
        if (bodyBean == null) bodyBean = new BodyBean();
        return bodyBean;
    }

    public void setBodyBean(BodyBean bodyBean) {
        this.bodyBean = bodyBean;
    }

}