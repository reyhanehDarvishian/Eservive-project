package com.rahgozin.gate.dto.queryFreeUnit.request;

import com.fasterxml.jackson.annotation.JsonProperty;

import javax.xml.bind.annotation.XmlAttribute;
import javax.xml.bind.annotation.XmlElement;


public class QueryFreeUnitRequestHeader {
    @JsonProperty("ns1:Version")
	QueryFreeUnitVersion version;
    String strVersion;
    @JsonProperty("ns1:BusinessCode")
    QueryFreeUnitBusinessCode businessCode;
    @JsonProperty("ns1:MessageSeq")
    QueryFreeUnitMessageSeq messageSeq;
    @JsonProperty("OwnershipInfo")
    QueryFreeUnitOwnershipInfo queryFreeUnitOwnershipInfo;
    @JsonProperty("AccessSecurity")
    QueryFreeUnitAccessSecurity queryFreeUnitAccessSecurity;
    @JsonProperty("OperatorInfo")
    QueryFreeUnitOperatorInfo queryFreeUnitOperatorInfo;


    @XmlAttribute(name = "ns1:Version")
    public QueryFreeUnitVersion getVersion() {
        if (version == null) version = new QueryFreeUnitVersion();
        return version;
    }

    public void setVersion(String version) {
        this.strVersion = version;
    }

    @XmlAttribute(name = "ns1:BusinessCode")
    public QueryFreeUnitBusinessCode getBusinessCode() {
        if (businessCode == null) businessCode = new QueryFreeUnitBusinessCode();
        return businessCode;
    }

    public void setBusinessCode(QueryFreeUnitBusinessCode businessCode) {
        this.businessCode = businessCode;
    }

    @XmlAttribute(name = "ns1:MessageSeq")
    public QueryFreeUnitMessageSeq getMessageSeq() {
        if (messageSeq == null) messageSeq = new QueryFreeUnitMessageSeq();
        return messageSeq;
    }

    public void setMessageSeq(QueryFreeUnitMessageSeq messageSeq) {
        this.messageSeq = messageSeq;
    }

    @XmlElement(name = "AccessSecurity")
    public QueryFreeUnitAccessSecurity getQueryFreeUnitAccessSecurity() {
        if (queryFreeUnitAccessSecurity == null) queryFreeUnitAccessSecurity = new QueryFreeUnitAccessSecurity();
        return queryFreeUnitAccessSecurity;
    }

    public void setQueryFreeUnitAccessSecurity(QueryFreeUnitAccessSecurity queryFreeUnitAccessSecurity) {
        this.queryFreeUnitAccessSecurity = queryFreeUnitAccessSecurity;
    }

    @XmlElement(name = "OperatorInfo")
    public QueryFreeUnitOperatorInfo getQueryFreeUnitOperatorInfo() {
        if (queryFreeUnitOperatorInfo == null) queryFreeUnitOperatorInfo = new QueryFreeUnitOperatorInfo();
        return queryFreeUnitOperatorInfo;
    }

    public void setQueryFreeUnitOperatorInfo(QueryFreeUnitOperatorInfo queryFreeUnitOperatorInfo) {
        this.queryFreeUnitOperatorInfo = queryFreeUnitOperatorInfo;
    }

    @XmlElement(name = "OwnershipInfo")
    public QueryFreeUnitOwnershipInfo getQueryFreeUnitOwnershipInfo() {
        if (queryFreeUnitOwnershipInfo == null) queryFreeUnitOwnershipInfo = new QueryFreeUnitOwnershipInfo();
        return queryFreeUnitOwnershipInfo;
    }

    public void setQueryFreeUnitOwnershipInfo(QueryFreeUnitOwnershipInfo queryFreeUnitOwnershipInfo) {
        this.queryFreeUnitOwnershipInfo = queryFreeUnitOwnershipInfo;
    }
}