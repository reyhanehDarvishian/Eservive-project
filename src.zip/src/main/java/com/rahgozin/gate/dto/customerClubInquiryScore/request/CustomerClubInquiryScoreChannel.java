package com.rahgozin.gate.dto.customerClubInquiryScore.request;

public class CustomerClubInquiryScoreChannel {
    private String channel;

    public String getChannel() {
        return channel;
    }

    public void setChannel(String channel) {
        this.channel = channel;
    }
}
