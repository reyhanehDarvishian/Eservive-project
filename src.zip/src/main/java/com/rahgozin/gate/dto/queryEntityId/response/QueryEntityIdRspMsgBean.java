package com.rahgozin.gate.dto.queryEntityId.response;

import com.fasterxml.jackson.annotation.JsonProperty;
import javax.xml.bind.annotation.XmlElement;
import java.util.ArrayList;
import java.util.List;


public class QueryEntityIdRspMsgBean {
@JsonProperty("queryEntityIdResponse") 
    List< QueryEntityIdResponseBean> queryEntityIdResponseBeanList ;
@JsonProperty("resultHeader") 
    ResultHeaderBean resultHeaderBean ;
  public void setQueryEntityIdResponseBeanList(List<QueryEntityIdResponseBean> queryEntityIdResponseBeanList) { 
		this.queryEntityIdResponseBeanList=queryEntityIdResponseBeanList;
	} 
	@XmlElement(name = "queryEntityIdResponse")
public List<QueryEntityIdResponseBean> getQueryEntityIdResponseBeanList() { 
		if(queryEntityIdResponseBeanList == null)
		queryEntityIdResponseBeanList=new ArrayList<QueryEntityIdResponseBean>(); 
		return queryEntityIdResponseBeanList;
	} 
    @XmlElement(name = "resultHeader")
    public ResultHeaderBean getResultHeaderBean() { 
		if(resultHeaderBean==null) resultHeaderBean=new ResultHeaderBean(); 
		return resultHeaderBean;
	} 
  public void setResultHeaderBean( ResultHeaderBean resultHeaderBean ) { 
		this.resultHeaderBean=resultHeaderBean;
	} 

}