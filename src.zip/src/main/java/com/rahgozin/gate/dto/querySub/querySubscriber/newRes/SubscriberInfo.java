package com.rahgozin.gate.dto.querySub.querySubscriber.newRes;

import com.fasterxml.jackson.annotation.JsonProperty;

import javax.xml.bind.annotation.XmlElement;
import java.util.ArrayList;
import java.util.List;


public class SubscriberInfo {
    @JsonProperty("subInfo")
    List<SubInfo> subInfoList;

    public void setSubInfoList(List<SubInfo> subInfoList) {
        this.subInfoList = subInfoList;
    }

    @XmlElement(name = "subInfo")
    public List<SubInfo> getSubInfoList() {
        if (subInfoList == null)
            subInfoList = new ArrayList<SubInfo>();
        return subInfoList;
    }

}