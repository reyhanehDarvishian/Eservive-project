package com.rahgozin.gate.dto.querySub.queryAccount.request;

import com.fasterxml.jackson.annotation.JsonProperty;

import javax.xml.bind.annotation.XmlElement;


public class CustAccessCodeReq {
    @JsonProperty("cms:customerId")
    String primaryIdentity;

    @XmlElement(name = "cms:customerId")
    public String getPrimaryIdentity() {
        return primaryIdentity;
    }

    public void setPrimaryIdentity(String primaryIdentity) {
        this.primaryIdentity = primaryIdentity;
    }
}