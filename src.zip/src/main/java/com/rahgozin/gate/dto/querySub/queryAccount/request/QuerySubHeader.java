package com.rahgozin.gate.dto.querySub.queryAccount.request;

public class QuerySubHeader {

}