package com.rahgozin.gate.dto.queryImsiinfo.response;

import com.fasterxml.jackson.annotation.JsonProperty;

import javax.xml.bind.annotation.XmlElement;
import java.util.ArrayList;
import java.util.List;


public class QueryIMSIInfoRspMsgBean {
    @JsonProperty("queryIMSIInfoResponse")
    List<QueryIMSIInfoResponseBean> queryIMSIInfoResponseBeanList;
    @JsonProperty("resultHeader")
    ResultHeaderBean resultHeaderBean;

    public void setQueryIMSIInfoResponseBeanList(List<QueryIMSIInfoResponseBean> queryIMSIInfoResponseBeanList) {
        this.queryIMSIInfoResponseBeanList = queryIMSIInfoResponseBeanList;
    }

    @XmlElement(name = "queryIMSIInfoResponse")
    public List<QueryIMSIInfoResponseBean> getQueryIMSIInfoResponseBeanList() {
        if (queryIMSIInfoResponseBeanList == null)
            queryIMSIInfoResponseBeanList = new ArrayList<QueryIMSIInfoResponseBean>();
        return queryIMSIInfoResponseBeanList;
    }

    @XmlElement(name = "resultHeader")
    public ResultHeaderBean getResultHeaderBean() {
        if (resultHeaderBean == null) resultHeaderBean = new ResultHeaderBean();
        return resultHeaderBean;
    }

    public void setResultHeaderBean(ResultHeaderBean resultHeaderBean) {
        this.resultHeaderBean = resultHeaderBean;
    }

}