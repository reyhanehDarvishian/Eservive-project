
package com.rahgozin.gate.dto.querySub.queryAccount.response;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonPropertyOrder;
import com.rahgozin.gate.dto.querySub.queryCustomer.response.PageQueryResponse;
import com.rahgozin.gate.dto.querySub.queryCustomer.response.SubscriberInfoRes;

import javax.annotation.Generated;
import java.util.ArrayList;
import java.util.List;

@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonPropertyOrder({
    "subscriberInfo",
    "pageQuery"
})
@Generated("jsonschema2pojo")
public class QuerySubscriberRes {

    @JsonProperty("subscriberInfo")
    private com.rahgozin.gate.dto.querySub.queryCustomer.response.SubscriberInfoRes subscriberInfoRes;


    private List<com.rahgozin.gate.dto.querySub.queryCustomer.response.SubscriberInfoRes> subscribersInfoRes=new ArrayList<>();
    @JsonProperty("pageQuery")
    private com.rahgozin.gate.dto.querySub.queryCustomer.response.PageQueryResponse pageQueryResponse;


    public void addToSubsInfo(com.rahgozin.gate.dto.querySub.queryCustomer.response.SubscriberInfoRes subInfoResponse) {
        subscribersInfoRes.add(subInfoResponse);

    }
    @JsonProperty("subscriberInfo")
    public com.rahgozin.gate.dto.querySub.queryCustomer.response.SubscriberInfoRes getSubscriberInfo() {
        return subscriberInfoRes;
    }

    @JsonProperty("subscriberInfo")
    public void setSubscriberInfo(com.rahgozin.gate.dto.querySub.queryCustomer.response.SubscriberInfoRes subscriberInfoRes) {
        addToSubsInfo(subscriberInfoRes);
        this.subscriberInfoRes = subscriberInfoRes;
    }

    @JsonProperty("pageQuery")
    public com.rahgozin.gate.dto.querySub.queryCustomer.response.PageQueryResponse getPageQuery() {
        return pageQueryResponse;
    }

    @JsonProperty("pageQuery")
    public void setPageQuery(PageQueryResponse pageQueryResponse) {
        this.pageQueryResponse = pageQueryResponse;
    }

    public List<com.rahgozin.gate.dto.querySub.queryCustomer.response.SubscriberInfoRes> getSubscribersInfoRes() {
        return subscribersInfoRes;
    }

    public void setSubscribersInfoRes(List<SubscriberInfoRes> subscribersInfoRes) {
        this.subscribersInfoRes = subscribersInfoRes;
    }
}
