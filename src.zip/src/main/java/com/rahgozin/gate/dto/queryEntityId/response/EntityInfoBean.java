package com.rahgozin.gate.dto.queryEntityId.response;

import javax.xml.bind.annotation.XmlAttribute;


public class EntityInfoBean {
    String entityId = "";
    String entityType = "";

    public void setEntityId(String entityId) {
        this.entityId = entityId;
    }

    @XmlAttribute(name = "entityId")
    public String getEntityId() {
        return entityId;
    }

    public void setEntityType(String entityType) {
        this.entityType = entityType;
    }

    @XmlAttribute(name = "entityType")
    public String getEntityType() {
        return entityType;
    }
}