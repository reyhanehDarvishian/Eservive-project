package com.rahgozin.gate.dto.changeImsiReport.request;

public class ChangeImsiReportHeader {
}
