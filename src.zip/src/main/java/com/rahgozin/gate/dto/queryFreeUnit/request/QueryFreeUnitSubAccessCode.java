package com.rahgozin.gate.dto.queryFreeUnit.request;

import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.dataformat.xml.annotation.JacksonXmlProperty;

import javax.xml.bind.annotation.XmlAttribute;


public class QueryFreeUnitSubAccessCode {
    @JacksonXmlProperty(isAttribute = true, localName = "xmlns:ns2")
    private String bbcommon = "http://www.huawei.com/bme/cbsinterface/bbcommon";

    @JsonProperty("ns2:PrimaryIdentity")
    private String primaryIdentity;

    public void setPrimaryIdentity(String primaryIdentity) {
        this.primaryIdentity = primaryIdentity;
    }

    @XmlAttribute(name = "ns2:PrimaryIdentity")
    public String getPrimaryIdentity() {
        return primaryIdentity;
    }

}