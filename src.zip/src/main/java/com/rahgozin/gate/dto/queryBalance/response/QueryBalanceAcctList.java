package com.rahgozin.gate.dto.queryBalance.response;

import com.fasterxml.jackson.annotation.JsonProperty;

import javax.xml.bind.annotation.XmlAttribute;
import javax.xml.bind.annotation.XmlElement;

public class QueryBalanceAcctList {
    String acctKey;
    @JsonProperty("AccountCredit")
    AccountCreditBean accountCreditBean;
    @JsonProperty("BalanceResult")
    BalanceResultBean balanceResultBean;

    public void setAcctKey(String acctKey) {
        this.acctKey = acctKey;
    }

    @XmlAttribute(name = "AcctKey")
    public String getAcctKey() {
        return acctKey;
    }

    @XmlElement(name = "AccountCredit")
    public AccountCreditBean getAccountCreditBean() {
        if (accountCreditBean == null) accountCreditBean = new AccountCreditBean();
        return accountCreditBean;
    }

    public void setAccountCreditBean(AccountCreditBean accountCreditBean) {
        this.accountCreditBean = accountCreditBean;
    }

    @XmlElement(name = "BalanceResult")
    public BalanceResultBean getBalanceResultBean() {
        if (balanceResultBean == null) balanceResultBean = new BalanceResultBean();
        return balanceResultBean;
    }

    public void setBalanceResultBean(BalanceResultBean balanceResultBean) {
        this.balanceResultBean = balanceResultBean;
    }
}