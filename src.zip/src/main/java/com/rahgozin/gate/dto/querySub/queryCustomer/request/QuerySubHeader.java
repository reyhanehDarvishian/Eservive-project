package com.rahgozin.gate.dto.querySub.queryCustomer.request;

public class QuerySubHeader {

}