package com.rahgozin.gate.dto.queryFreeUnit.request;

import com.fasterxml.jackson.annotation.JsonProperty;

import javax.xml.bind.annotation.XmlAttribute;


public class QueryFreeUnitAccessSecurity {
    @JsonProperty("LoginSystemCode")
    private String loginSystemCode;
    @JsonProperty("Password")
    private String password;

    public void setLoginSystemCode(String loginSystemCode) {
        this.loginSystemCode = loginSystemCode;
    }

    @XmlAttribute(name = "LoginSystemCode")
    public String getLoginSystemCode() {
        return loginSystemCode;
    }

    public void setPassword(String password) {
        this.password = password;
    }

    @XmlAttribute(name = "Password")
    public String getPassword() {
        return password;
    }

}