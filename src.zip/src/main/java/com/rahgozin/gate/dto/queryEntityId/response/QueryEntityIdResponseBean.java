package com.rahgozin.gate.dto.queryEntityId.response;

import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.databind.ObjectMapper;

import javax.xml.bind.annotation.XmlAttribute;
import javax.xml.bind.annotation.XmlElement;


public class QueryEntityIdResponseBean {
@JsonProperty("entityInfo")
    EntityInfoBean entityInfoBean ;@XmlElement(name = "entityInfo")
    public EntityInfoBean getEntityInfoBean() { 
		if(entityInfoBean==null) entityInfoBean=new EntityInfoBean(); 
		return entityInfoBean;
	} 
  public void setEntityInfoBean( EntityInfoBean entityInfoBean ) { 
		this.entityInfoBean=entityInfoBean;
	} 

}