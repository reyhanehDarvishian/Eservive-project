package com.rahgozin.gate.dto.queryCustomerInfo.request;

public class QueryCustomerInfoHeader {
}
