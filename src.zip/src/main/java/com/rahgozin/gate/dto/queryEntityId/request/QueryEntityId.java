package com.rahgozin.gate.dto.queryEntityId.request;


public class QueryEntityId {
    private String channel;
    private EntityIdQueryObj queryObj;

    public String getChannel() {
        return channel;
    }

    public void setChannel(String channel) {
        this.channel = channel;
    }

    public EntityIdQueryObj getQueryObj() {
        if (queryObj == null)
            queryObj = new EntityIdQueryObj();
        return queryObj;
    }

    public void setQueryObj(EntityIdQueryObj queryObj) {
        this.queryObj = queryObj;
    }

    @Override
    public String toString() {
        return "channel"
                + getChannel()
                + ", queryObj=" + getQueryObj() + "]";

    }
}
