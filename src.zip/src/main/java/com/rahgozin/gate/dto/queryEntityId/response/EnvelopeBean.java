package com.rahgozin.gate.dto.queryEntityId.response;

import com.fasterxml.jackson.annotation.JsonProperty;

import javax.xml.bind.annotation.XmlAttribute;
import javax.xml.bind.annotation.XmlElement;


public class EnvelopeBean {
@JsonProperty("Body")
    BodyBean bodyBean ;

    @XmlElement(name = "Body")
    public BodyBean getBodyBean() { 
		if(bodyBean==null) bodyBean=new BodyBean(); 
		return bodyBean;
	} 
  public void setBodyBean( BodyBean bodyBean ) { 
		this.bodyBean=bodyBean;
	} 


}