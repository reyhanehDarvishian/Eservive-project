package com.rahgozin.gate.dto.changeSubscriberIdentity.request;

public class ChangeSubHeader {
}
