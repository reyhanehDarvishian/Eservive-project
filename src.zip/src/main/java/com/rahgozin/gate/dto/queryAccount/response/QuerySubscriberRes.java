
package com.rahgozin.gate.dto.queryAccount.response;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonPropertyOrder;

import javax.annotation.Generated;

@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonPropertyOrder({
    "subscriberInfo",
    "pageQuery"
})
@Generated("jsonschema2pojo")
public class QuerySubscriberRes {

    @JsonProperty("subscriberInfo")
    private SubscriberInfoRes subscriberInfoRes;
    @JsonProperty("pageQuery")
    private PageQueryResponse pageQueryResponse;

    @JsonProperty("subscriberInfo")
    public SubscriberInfoRes getSubscriberInfo() {
        return subscriberInfoRes;
    }

    @JsonProperty("subscriberInfo")
    public void setSubscriberInfo(SubscriberInfoRes subscriberInfoRes) {
        this.subscriberInfoRes = subscriberInfoRes;
    }

    @JsonProperty("pageQuery")
    public PageQueryResponse getPageQuery() {
        return pageQueryResponse;
    }

    @JsonProperty("pageQuery")
    public void setPageQuery(PageQueryResponse pageQueryResponse) {
        this.pageQueryResponse = pageQueryResponse;
    }

}
