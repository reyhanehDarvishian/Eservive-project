package com.rahgozin.gate.dto.queryBalance.request;

import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.dataformat.xml.annotation.JacksonXmlProperty;

import javax.xml.bind.annotation.XmlElement;

public class QueryBalanceReqHeader {
    @JacksonXmlProperty(localName = "xmlns:cbs", namespace = "http://www.huawei.com/bme/cbsinterface/cbscommon")
    @JsonProperty("cbs:Version")
    int version;
    @JsonProperty("cbs:BusinessCode")
    BusinessCode businessCode;
    String businessCodeStr;
    @JsonProperty("cbs:MessageSeq")
    MessageSequence messageSeq;
    String messageSeqStr;
    @JsonProperty("OwnershipInfo")
    QueryBalanceOwnershipInfo queryBalanceOwnershipInfo;
    @JsonProperty("AccessSecurity")
    QueryBalanceAccessSecurityReq accessSecurityReq;
    @JsonProperty("OperatorInfo")
    QueryBalanceOperatorInfoReq operatorInfoReq;

    @XmlElement(name = "cbs:Version")
    public int getVersion() {
        return version;
    }

    public void setVersion(int version) {
        this.version = version;
    }
//    public Version getVersion() {
//        if (version == null) version = new Version();
//        return version;
//    }
//
//    public void setVersion(int version) {
//        this.intVersion = version;
//    }

    @XmlElement(name = "cbs:BusinessCode")
    public BusinessCode getBusinessCode() {
        if (businessCode == null) businessCode = new BusinessCode();
        return businessCode;
    }

    public void setBusinessCode(String businessCode) {
        this.businessCodeStr = businessCode;
    }

    @XmlElement(name = "cbs:MessageSeq")
    public MessageSequence getMessageSeq() {
        if (messageSeq == null) messageSeq = new MessageSequence();
        return messageSeq;
    }

    public void setMessageSeq(String messageSeq) {
        this.messageSeqStr = messageSeq;
    }

    @JsonIgnore
    @XmlElement(name = "OwnershipInfo")
    public QueryBalanceOwnershipInfo getOwnershipInfo() {
        if (queryBalanceOwnershipInfo == null) queryBalanceOwnershipInfo = new QueryBalanceOwnershipInfo();
        return queryBalanceOwnershipInfo;
    }

    public void setOwnershipInfo(QueryBalanceOwnershipInfo queryBalanceOwnershipInfo) {
        this.queryBalanceOwnershipInfo = queryBalanceOwnershipInfo;
    }


    @JsonIgnore
    @XmlElement(name = "AccessSecurity")
    public QueryBalanceAccessSecurityReq getAccessSecurityReq() {
        if (accessSecurityReq == null) accessSecurityReq = new QueryBalanceAccessSecurityReq();
        return accessSecurityReq;
    }

    public void setAccessSecurityReq(QueryBalanceAccessSecurityReq accessSecurityReq) {
        this.accessSecurityReq = accessSecurityReq;
    }


    @JsonIgnore
    @XmlElement(name = "OperatorInfo")
    public QueryBalanceOperatorInfoReq getOperatorInfoReq() {
        if (operatorInfoReq == null) operatorInfoReq = new QueryBalanceOperatorInfoReq();
        return operatorInfoReq;
    }

    public void setOperatorInfoReq(QueryBalanceOperatorInfoReq operatorInfoReq) {
        this.operatorInfoReq = operatorInfoReq;
    }
}
