package com.rahgozin.gate.dto.queryBalance.request;

public class QueryBalanceHeader {
}
