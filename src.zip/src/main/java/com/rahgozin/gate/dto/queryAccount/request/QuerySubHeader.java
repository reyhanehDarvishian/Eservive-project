package com.rahgozin.gate.dto.queryAccount.request;

public class QuerySubHeader {

}