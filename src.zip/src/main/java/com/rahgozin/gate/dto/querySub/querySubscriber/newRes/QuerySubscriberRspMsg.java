package com.rahgozin.gate.dto.querySub.querySubscriber.newRes;

import com.fasterxml.jackson.annotation.JsonProperty;

import javax.xml.bind.annotation.XmlElement;
import java.util.ArrayList;
import java.util.List;


public class QuerySubscriberRspMsg {
    @JsonProperty("resultHeader")
    ResultHeader resultHeader;
    @JsonProperty("querySubscriberResponse")
    List<QuerySubscriberResponse> querySubscriberResponseList;

    @XmlElement(name = "resultHeader")
    public ResultHeader getResultHeader() {
        if (resultHeader == null) resultHeader = new ResultHeader();
        return resultHeader;
    }

    public void setResultHeader(ResultHeader resultHeader) {
        this.resultHeader = resultHeader;
    }

    public void setQuerySubscriberResponseList(List<QuerySubscriberResponse> querySubscriberResponseList) {
        this.querySubscriberResponseList = querySubscriberResponseList;
    }

    @XmlElement(name = "querySubscriberResponse")
    public List<QuerySubscriberResponse> getQuerySubscriberResponseList() {
        if (querySubscriberResponseList == null)
            querySubscriberResponseList = new ArrayList<QuerySubscriberResponse>();
        return querySubscriberResponseList;
    }

}