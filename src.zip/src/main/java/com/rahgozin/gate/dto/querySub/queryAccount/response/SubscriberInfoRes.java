
package com.rahgozin.gate.dto.querySub.queryAccount.response;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonPropertyOrder;

@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonPropertyOrder({
        "subInfo"
})
public class SubscriberInfoRes {
    @JsonProperty("subInfo")
    private SubInfoResponse subInfoResponse;

    @JsonProperty("subInfo")
    public SubInfoResponse getSubInfo() {
        return subInfoResponse;
    }

    public void setSubInfo(SubInfoResponse subInfoResponse) {
        this.subInfoResponse = subInfoResponse;
    }

}