package com.rahgozin.gate.dto.queryFreeUnit.request;

import com.fasterxml.jackson.annotation.JsonProperty;

import javax.xml.bind.annotation.XmlAttribute;


public class QueryFreeUnitOwnershipInfo {
    @JsonProperty("BEID")
    private String bEID;

    public void setBEID(String bEID) {
        this.bEID = bEID;
    }

    @XmlAttribute(name = "BEID")
    public String getBEID() {
        return bEID;
    }

}