package com.rahgozin.gate.dto.queryPaymentLog.request;

public class QueryPaymentLogFetchRowNum {
}
