package com.rahgozin.gate.dto.queryEntityId.response;

import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.databind.ObjectMapper;

import javax.xml.bind.annotation.XmlAttribute;
import javax.xml.bind.annotation.XmlElement;


public class BodyBean {
@JsonProperty("queryEntityIdRspMsg") 
    QueryEntityIdRspMsgBean queryEntityIdRspMsgBean ;
    @XmlElement(name = "queryEntityIdRspMsg")
    public QueryEntityIdRspMsgBean getQueryEntityIdRspMsgBean() { 
		if(queryEntityIdRspMsgBean==null) queryEntityIdRspMsgBean=new QueryEntityIdRspMsgBean(); 
		return queryEntityIdRspMsgBean;
	} 
  public void setQueryEntityIdRspMsgBean( QueryEntityIdRspMsgBean queryEntityIdRspMsgBean ) { 
		this.queryEntityIdRspMsgBean=queryEntityIdRspMsgBean;
	} 

}