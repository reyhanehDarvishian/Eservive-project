package com.rahgozin.gate.dto.queryImsiinfo.response;

import com.fasterxml.jackson.annotation.JsonProperty;

import javax.xml.bind.annotation.XmlElement;


public class BodyBean {
    @JsonProperty("queryIMSIInfoRspMsg")
    QueryIMSIInfoRspMsgBean queryIMSIInfoRspMsgBean;

    @XmlElement(name = "queryIMSIInfoRspMsg")
    public QueryIMSIInfoRspMsgBean getQueryIMSIInfoRspMsgBean() {
        if (queryIMSIInfoRspMsgBean == null) queryIMSIInfoRspMsgBean = new QueryIMSIInfoRspMsgBean();
        return queryIMSIInfoRspMsgBean;
    }

    public void setQueryIMSIInfoRspMsgBean(QueryIMSIInfoRspMsgBean queryIMSIInfoRspMsgBean) {
        this.queryIMSIInfoRspMsgBean = queryIMSIInfoRspMsgBean;
    }

}