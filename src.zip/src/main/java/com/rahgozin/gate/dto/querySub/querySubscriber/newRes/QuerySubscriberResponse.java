package com.rahgozin.gate.dto.querySub.querySubscriber.newRes;

import com.fasterxml.jackson.annotation.JsonProperty;

import javax.xml.bind.annotation.XmlElement;


public class QuerySubscriberResponse {
    @JsonProperty("subscriberInfo")
    SubscriberInfo subscriberInfo;
    @JsonProperty("pageQuery")
    PageQuery pageQuery;

    @XmlElement(name = "subscriberInfo")
    public SubscriberInfo getSubscriberInfo() {
        if (subscriberInfo == null) subscriberInfo = new SubscriberInfo();
        return subscriberInfo;
    }

    public void setSubscriberInfo(SubscriberInfo subscriberInfo) {
        this.subscriberInfo = subscriberInfo;
    }

    @XmlElement(name = "pageQuery")
    public PageQuery getPageQuery() {
        if (pageQuery == null) pageQuery = new PageQuery();
        return pageQuery;
    }

    public void setPageQuery(PageQuery pageQuery) {
        this.pageQuery = pageQuery;
    }

}