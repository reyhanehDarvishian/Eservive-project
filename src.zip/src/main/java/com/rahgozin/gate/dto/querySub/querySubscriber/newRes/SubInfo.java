package com.rahgozin.gate.dto.querySub.querySubscriber.newRes;

import javax.xml.bind.annotation.XmlAttribute;


public class SubInfo {
    String activeDate = "";
    String beId = "";
    String brand = "";
    String defaultAcctId = "";
    String effDate = "";
    String expDate = "";
    String iccid = "";
    String imsi = "";
    String networkType = "";
    String offeringId = "";
    String ownerPartyRoleId = "";
    String ownerPartyRoleType = "";
    String paymentType = "";
    String primaryIdentity = "";
    String remark = "";
    String salesChannelId = "";
    String salesChannelType = "";
    String status = "";
    String statusDetail = "";
    String statusTime = "";
    String subType = "";
    String subsId = "";
    String subsName = "";
    String subsVocieLang = "";
    String subsWrittenLang = "";

    public void setActiveDate(String activeDate) {
        this.activeDate = activeDate;
    }

    @XmlAttribute(name = "activeDate")
    public String getActiveDate() {
        return activeDate;
    }

    public void setBeId(String beId) {
        this.beId = beId;
    }

    @XmlAttribute(name = "beId")
    public String getBeId() {
        return beId;
    }

    public void setBrand(String brand) {
        this.brand = brand;
    }

    @XmlAttribute(name = "brand")
    public String getBrand() {
        return brand;
    }

    public void setDefaultAcctId(String defaultAcctId) {
        this.defaultAcctId = defaultAcctId;
    }

    @XmlAttribute(name = "defaultAcctId")
    public String getDefaultAcctId() {
        return defaultAcctId;
    }

    public void setEffDate(String effDate) {
        this.effDate = effDate;
    }

    @XmlAttribute(name = "effDate")
    public String getEffDate() {
        return effDate;
    }

    public void setExpDate(String expDate) {
        this.expDate = expDate;
    }

    @XmlAttribute(name = "expDate")
    public String getExpDate() {
        return expDate;
    }

    public void setIccid(String iccid) {
        this.iccid = iccid;
    }

    @XmlAttribute(name = "iccid")
    public String getIccid() {
        return iccid;
    }

    public void setImsi(String imsi) {
        this.imsi = imsi;
    }

    @XmlAttribute(name = "imsi")
    public String getImsi() {
        return imsi;
    }

    public void setNetworkType(String networkType) {
        this.networkType = networkType;
    }

    @XmlAttribute(name = "networkType")
    public String getNetworkType() {
        return networkType;
    }

    public void setOfferingId(String offeringId) {
        this.offeringId = offeringId;
    }

    @XmlAttribute(name = "offeringId")
    public String getOfferingId() {
        return offeringId;
    }

    public void setOwnerPartyRoleId(String ownerPartyRoleId) {
        this.ownerPartyRoleId = ownerPartyRoleId;
    }

    @XmlAttribute(name = "ownerPartyRoleId")
    public String getOwnerPartyRoleId() {
        return ownerPartyRoleId;
    }

    public void setOwnerPartyRoleType(String ownerPartyRoleType) {
        this.ownerPartyRoleType = ownerPartyRoleType;
    }

    @XmlAttribute(name = "ownerPartyRoleType")
    public String getOwnerPartyRoleType() {
        return ownerPartyRoleType;
    }

    public void setPaymentType(String paymentType) {
        this.paymentType = paymentType;
    }

    @XmlAttribute(name = "paymentType")
    public String getPaymentType() {
        return paymentType;
    }

    public void setPrimaryIdentity(String primaryIdentity) {
        this.primaryIdentity = primaryIdentity;
    }

    @XmlAttribute(name = "primaryIdentity")
    public String getPrimaryIdentity() {
        return primaryIdentity;
    }

    public void setRemark(String remark) {
        this.remark = remark;
    }

    @XmlAttribute(name = "remark")
    public String getRemark() {
        return remark;
    }

    public void setSalesChannelId(String salesChannelId) {
        this.salesChannelId = salesChannelId;
    }

    @XmlAttribute(name = "salesChannelId")
    public String getSalesChannelId() {
        return salesChannelId;
    }

    public void setSalesChannelType(String salesChannelType) {
        this.salesChannelType = salesChannelType;
    }

    @XmlAttribute(name = "salesChannelType")
    public String getSalesChannelType() {
        return salesChannelType;
    }

    public void setStatus(String status) {
        this.status = status;
    }

    @XmlAttribute(name = "status")
    public String getStatus() {
        return status;
    }

    public void setStatusDetail(String statusDetail) {
        this.statusDetail = statusDetail;
    }

    @XmlAttribute(name = "statusDetail")
    public String getStatusDetail() {
        return statusDetail;
    }

    public void setStatusTime(String statusTime) {
        this.statusTime = statusTime;
    }

    @XmlAttribute(name = "statusTime")
    public String getStatusTime() {
        return statusTime;
    }

    public void setSubType(String subType) {
        this.subType = subType;
    }

    @XmlAttribute(name = "subType")
    public String getSubType() {
        return subType;
    }

    public void setSubsId(String subsId) {
        this.subsId = subsId;
    }

    @XmlAttribute(name = "subsId")
    public String getSubsId() {
        return subsId;
    }

    public void setSubsName(String subsName) {
        this.subsName = subsName;
    }

    @XmlAttribute(name = "subsName")
    public String getSubsName() {
        return subsName;
    }

    public void setSubsVocieLang(String subsVocieLang) {
        this.subsVocieLang = subsVocieLang;
    }

    @XmlAttribute(name = "subsVocieLang")
    public String getSubsVocieLang() {
        return subsVocieLang;
    }

    public void setSubsWrittenLang(String subsWrittenLang) {
        this.subsWrittenLang = subsWrittenLang;
    }

    @XmlAttribute(name = "subsWrittenLang")
    public String getSubsWrittenLang() {
        return subsWrittenLang;
    }

}