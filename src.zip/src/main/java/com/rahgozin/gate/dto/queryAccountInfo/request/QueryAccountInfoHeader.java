package com.rahgozin.gate.dto.queryAccountInfo.request;

public class QueryAccountInfoHeader {
}
