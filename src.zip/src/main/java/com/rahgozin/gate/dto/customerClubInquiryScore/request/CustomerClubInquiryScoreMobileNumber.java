package com.rahgozin.gate.dto.customerClubInquiryScore.request;

public class CustomerClubInquiryScoreMobileNumber {
    private String mobileNumber;

    public String getMobileNumber() {
        return mobileNumber;
    }

    public void setMobileNumber(String mobileNumber) {
        this.mobileNumber = mobileNumber;
    }
}
