package com.rahgozin.gate.dto.querySub.querySubscriber.request;

public class QuerySubHeader {

}