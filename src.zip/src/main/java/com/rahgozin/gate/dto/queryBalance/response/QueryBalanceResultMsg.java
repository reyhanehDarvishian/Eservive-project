package com.rahgozin.gate.dto.queryBalance.response;

import com.fasterxml.jackson.annotation.JsonProperty;

import javax.xml.bind.annotation.XmlElement;
import java.util.ArrayList;
import java.util.List;

public class QueryBalanceResultMsg {
    @JsonProperty("QueryBalanceResult")
    List<QueryBalanceResult> queryBalanceResultList;
    @JsonProperty("ResultHeader")
	QueryBalanceResResultHeader queryBalanceResResultHeader;

    public void setQueryBalanceResultBeanList(List<QueryBalanceResult> queryBalanceResultList) {
        this.queryBalanceResultList = queryBalanceResultList;
    }

    @XmlElement(name = "QueryBalanceResult")
    public List<QueryBalanceResult> getQueryBalanceResultBeanList() {
        if (queryBalanceResultList == null)
            queryBalanceResultList = new ArrayList<QueryBalanceResult>();
        return queryBalanceResultList;
    }

    @XmlElement(name = "ResultHeader")
    public QueryBalanceResResultHeader getResultHeaderBean() {
        if (queryBalanceResResultHeader == null) queryBalanceResResultHeader = new QueryBalanceResResultHeader();
        return queryBalanceResResultHeader;
    }

    public void setResultHeaderBean(QueryBalanceResResultHeader queryBalanceResResultHeader) {
        this.queryBalanceResResultHeader = queryBalanceResResultHeader;
    }
}