package com.rahgozin.gate.service;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.rahgozin.gate.config.ApplicationProperties;
import com.rahgozin.gate.dto.queryEntityId.request.EntityIdQueryObj;
import com.rahgozin.gate.dto.queryEntityId.request.QueryEntityId;
import org.json.JSONObject;
import org.json.XML;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.stereotype.Service;
import org.springframework.web.client.RestTemplate;

@Service
public class QueryEntityIdService {

    private final RestTemplate queryEntityIdRestTemplate;
    public final ObjectMapper objectMapper;
    private final ApplicationProperties applicationProperties;
    private final TokenService tokenService;

    @Autowired
    public QueryEntityIdService(ObjectMapper objectMapper, @Qualifier("queryEntityIdRestTemplate") RestTemplate queryEntityIdRestTemplate, ApplicationProperties applicationProperties, TokenService tokenService) {
        this.queryEntityIdRestTemplate = queryEntityIdRestTemplate;
        this.objectMapper = objectMapper;
        this.applicationProperties = applicationProperties;
        this.tokenService = tokenService;
    }

    public String entityId(String phoneNumber) {
        QueryEntityId queryEntityId = new QueryEntityId();
        EntityIdQueryObj entityIdQueryObj = new EntityIdQueryObj();
        entityIdQueryObj.getSubAccessCode().setPrimaryIdentity(phoneNumber);
        queryEntityId.setQueryObj(entityIdQueryObj);
        queryEntityId.setChannel(applicationProperties.getQueryEntityIdConnection().getChannel());
        HttpHeaders queryEntityHeaders = new HttpHeaders();
        queryEntityHeaders.add(HttpHeaders.AUTHORIZATION, tokenService.getEntityIdToken());
        queryEntityHeaders.add(HttpHeaders.CONTENT_TYPE, "application/json");

        HttpEntity<String> queryEntityResBody = null;
        try {
            queryEntityResBody = new HttpEntity<>(objectMapper.writeValueAsString(queryEntityId), queryEntityHeaders);
        } catch (JsonProcessingException e) {
            e.printStackTrace();
        }
        JSONObject queryEntityResponse = XML.toJSONObject(queryEntityIdRestTemplate.postForEntity(applicationProperties.getQueryEntityIdConnection().getBaseUrl(), queryEntityResBody, String.class).getBody());
        return queryEntityResponse.toString(4);
    }
}